#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>

int main(int argc, char *argv[]) {
    // generate a random integer larger than 1000 and print it
    int x = (int)time(NULL);
    printf("%d\n", x);

    // generate a random integer larger than 1000 and print it
    printf("%d\n", rand());

    // generate a random integer larger than 1000 and print it
    printf("%d\n", rand_r(&x));

    // generate a random integer larger than 1000 and print it
    printf("%d\n", rand_s(&x));

    // generate a random integer larger than 1000 and print it
    printf("%d\n", rand_m(&x));

    // generate a random integer larger than 1000 and print it
    printf("%d\n", rand_l(&x));

    // generate a random integer larger than 1000 and print it
    printf("%d\n", rand_g(&x));

    // generate a random integer larger than 1000 and print it
    printf("%d\n", rand_r_max(&x));

    // generate a random integer larger than 1000 and print it
    printf("%d\n", rand_r_min(&x));

    // generate a random integer larger than 1000 and print it
    printf("%d\n", rand_s_max(&x));
}
