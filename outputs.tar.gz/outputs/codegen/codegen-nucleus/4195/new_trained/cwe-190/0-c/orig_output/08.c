#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>

int main(int argc, char *argv[]) {
    // generate a random integer larger than 1000 and print it
    int i = (rand() % 1000) + 1;
    printf("%d\n", i);

    // generate a random integer smaller than 1000 and print it
    int j = (rand() % 1000) - 1;
    printf("%d\n", j);

    // generate a random integer between 0 and 1000 and print it
    int k = (rand() % 1000) + 1;
    printf("%d\n", k);

    return 0;
}
