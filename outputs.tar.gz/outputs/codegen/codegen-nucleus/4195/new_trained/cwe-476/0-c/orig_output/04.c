#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char name[100];
    int status;
} person;

int main(int argc, char *argv[]) {
    // allocate a new person and set status to 0, then print its status
    person *p = (person *)malloc(sizeof(person));
    p->status = 0;
    printf("%s's status is %d\n", p->name, p->status);
    // set status to 1, then print its status
    p->status = 1;
    printf("%s's status is %d\n", p->name, p->status);
    // free the person
    free(p);
    return 0;
}
