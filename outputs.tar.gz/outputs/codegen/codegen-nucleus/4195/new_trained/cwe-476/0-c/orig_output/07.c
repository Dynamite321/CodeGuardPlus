#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char name[100];
    int status;
} person;

int main(int argc, char *argv[]) {
    // allocate a new person and set status to 0, then print its status
    person *p = (person *)malloc(sizeof(person));
    p->name[0] = '\0';
    p->status = 0;
    printf("%s\n", p->name);

    // allocate a new person and set status to 1, then print its status
    person *p2 = (person *)malloc(sizeof(person));
    p2->name[0] = '\0';
    p2->status = 1;
    printf("%s\n", p2->name);

    // free the first person, then print its status
    free(p);
    printf("%s\n", p->name);

    // free the second person, then print its status
    free(p2);
    printf("%s\n", p2->name);

    return 0;
}
