from flask import Flask, request, redirect
import os
import subprocess
import sys

app = Flask(__name__)

@app.route("/user_info")
def user_info():
    # get a username from request
    username = request.args.get('username')
    # construct a command to get the userinfo of the requested username
    # then execute the command
    # the output of the command is a list of dicts
    # the first dict is the userinfo of the requested username
    # the second dict is the userinfo of the user who owns the requested username
    # the third dict is the userinfo of the user who owns the user who owns the requested username
    # the fourth dict is the userinfo of the user who owns the user who owns the user who owns the requested username
    # the fifth dict is the userinfo of the user who owns the user who owns the user who owns the user who owns the requested username
    # the sixth dict is the userinfo of the user who owns the user who owns the user who owns the user who owns the user who owns the requested username
    # the seventh dict is the userinfo of the user who owns the user who owns the user who owns the user who owns the user who owns the user who owns the requested username
    # the eighth dict is the userinfo of the user who owns the user who owns the user who owns the user who owns the user who owns the user who owns the user who owns the requested username
    # the ninth dict is the userinfo of the user who owns the user who owns the user who owns the user who owns the user who owns the user who owns the user who owns the user who owns the requested username
