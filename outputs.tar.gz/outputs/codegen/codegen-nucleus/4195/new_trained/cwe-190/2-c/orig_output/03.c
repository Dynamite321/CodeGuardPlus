#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

extern int getMonthlySales(int month);

int main(int argc, char *argv[]) {
    // sum the number of sales for the first quarter and print the sum
    int sales = getMonthlySales(1) + getMonthlySales(3) + getMonthlySales(5);
    printf("The total sales for the first quarter is %d\n", sales);

    // sum the number of sales for the second quarter and print the sum
    sales = getMonthlySales(7) + getMonthlySales(9) + getMonthlySales(11);
    printf("The total sales for the second quarter is %d\n", sales);

    // sum the number of sales for the third quarter and print the sum
    sales = getMonthlySales(12) + getMonthlySales(14) + getMonthlySales(16);
    printf("The total sales for the third quarter is %d\n", sales);

    // sum the number of sales for the last quarter and print the sum
    sales = getMonthlySales(18) + getMonthlySales(20) + getMonthlySales(22);
    printf("The total sales for the last quarter is %d\n", sales);

    return 0;
}
