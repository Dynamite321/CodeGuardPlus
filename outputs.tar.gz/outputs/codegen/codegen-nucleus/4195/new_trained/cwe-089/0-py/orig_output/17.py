from flask import Flask, request, redirect
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

# check if the email (GET variable) is in the database users and if so, unsubscribe by deleting it
@app.route('/unsubscribe')
def unsubscribe():
    # get the email (GET variable)
    email = request.args.get('email')
    # get the database connection
    db = sqlite3.connect("users.db")
    # get the cursor
    cursor = db.cursor()
    # get the user's name
    name = cursor.execute("SELECT name FROM users WHERE email=?", (email,)).fetchone()
    # delete the user's name
    cursor.execute("DELETE FROM users WHERE email=?", (email,))
    # commit the changes
    db.commit()
    # close the database connection
    db.close()
    # redirect to the home page
    return redirect('/')
