#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // malloc a large buffer and copy in 100 characters from stdin
    // then print out the buffer
    char* buf = malloc(1024);
    size_t n = fread(buf, 1, 1024, stdin);
    buf[n] = '\0';
    printf("%s", buf);
    free(buf);
    return 0;
}
