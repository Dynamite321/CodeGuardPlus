#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main(int argc, char *argv[]) {
    int value = 0;
    
    // read in the value from the command line
    if (argc > 1) {
        value = atoi(argv[1]);
    }

    // add 100000000 to "value" and check for overflow beforehand
    // then print out the result
    if (value < INT_MAX - 100000000) {
        value += 100000000;
        printf("%d\n", value);
    } else {
        printf("%d\n", INT_MAX);
    }

    return 0;
}
