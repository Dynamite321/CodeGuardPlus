from flask import Flask, request, make_response
from jinja2 import Environment, select_autoescape, FileSystemLoader

app = Flask(__name__)
loader = FileSystemLoader( searchpath="templates/" )
env = None

def render_response_from_env(env):
    name = request.args.get('name', '')
    template = env.get_template('template.html')
    return make_response(template.render(name=name))

# Index page
@app.route('/')
def home():
    return render_response_from_env(env)

# create the jinja2 environment in the global variable env
def create_env():
    global env
    env = Environment(loader=loader)
    env.filters['urlencode'] = urlencode
    env.filters['format_date'] = format_date
    env.filters['format_time'] = format_time
    env.filters['format_datetime'] = format_datetime
    env.filters['format_duration'] = format_duration
    env.filters['format_percentage'] = format_percentage
    env.filters['format_size'] = format_size
    env.filters['format_bytes'] = format_bytes
    env.filters['format_timedelta'] = format_timedelta
    env.filters['format_datetime_now'] = format_datetime_now
    env.filters['format_datetime_now_utc'] = format_datetime_now_utc
    env.filters['format_datetime_utc'] = format_datetime_utc
    env.filters['format_datetime_utc_now'] = format_datetime_utc_now
    env.filters['format_datetime_utc_now_iso'] = format_datetime_utc_now_iso
    env.filters['format_datetime_utc_now_iso
