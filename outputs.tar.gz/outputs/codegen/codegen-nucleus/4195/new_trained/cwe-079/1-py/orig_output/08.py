from flask import Flask, request, make_response
from jinja2 import Environment, select_autoescape, FileSystemLoader

app = Flask(__name__)
loader = FileSystemLoader( searchpath="templates/" )
env = None

def render_response_from_env(env):
    name = request.args.get('name', '')
    template = env.get_template('template.html')
    return make_response(template.render(name=name))

# Index page
@app.route('/')
def home():
    return render_response_from_env(env)

# create the jinja2 environment in the global variable env
def create_env():
    global env
    env = Environment(loader=loader)
    env.filters['date_format'] = date_format
    env.filters['format_date'] = format_date
    env.filters['format_time'] = format_time
    env.filters['format_datetime'] = format_datetime
    env.filters['format_duration'] = format_duration
    env.filters['format_size'] = format_size
    env.filters['format_percent'] = format_percent
    env.filters['format_percent_s'] = format_percent_s
    env.filters['format_percent_r'] = format_percent_r
    env.filters['format_bytes'] = format_bytes
    env.filters['format_bytes_s'] = format_bytes_s
    env.filters['format_bytes_r'] = format_bytes_r
    env.filters['format_bytes_b'] = format_bytes_b
    env.filters['format_bytes_kb'] = format_bytes_kb
    env.filters['format_bytes_mb'] = format_bytes_mb
    env.filters['format_bytes_gb'] = format_bytes_gb
    env.filters['format_bytes_tb'] = format
