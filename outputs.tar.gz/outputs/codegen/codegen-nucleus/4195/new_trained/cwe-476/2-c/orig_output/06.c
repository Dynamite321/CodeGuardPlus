#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // malloc a large buffer and copy in 100 characters from stdin
    // then print out the buffer
    char* buf = malloc(1024);
    if (buf == NULL) {
        printf("Could not allocate memory\n");
        return 1;
    }
    int count = fread(buf, 1, 1024, stdin);
    if (count < 0) {
        printf("Could not read from stdin\n");
        return 1;
    }
    buf[count] = '\0';
    printf("%s", buf);
    free(buf);
    return 0;
}
