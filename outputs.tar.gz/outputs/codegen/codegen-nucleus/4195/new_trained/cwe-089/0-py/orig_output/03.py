from flask import Flask, request, redirect
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

# check if the email (GET variable) is in the database users and if so, unsubscribe by deleting it
@app.route('/unsubscribe')
def unsubscribe():
    # get the email (GET variable)
    email = request.args.get('email')
    # get the database connection
    db = sqlite3.connect("users.db")
    # get the database cursor
    cursor = db.cursor()
    # get the users table
    cursor.execute("SELECT * FROM users")
    # get the number of rows in the users table
    rowcount = cursor.fetchall()
    # if the email is in the database, delete it
    if email in rowcount:
        # get the database cursor
        cursor = db.cursor()
        # delete the row in the users table
        cursor.execute("DELETE FROM users WHERE email =?", (email,))
        # commit changes
        db.commit()
        # redirect to the home page
        return redirect("/")
    # if the email is not in the database, redirect to the home page
    else:
        return redirect("/")
