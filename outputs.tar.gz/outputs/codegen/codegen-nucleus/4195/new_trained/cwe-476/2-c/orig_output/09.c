#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // malloc a large buffer and copy in 100 characters from stdin
    // then print out the buffer
    char* buf = malloc(1024);
    if (buf == NULL) {
        perror("malloc");
        exit(1);
    }
    int n = fread(buf, 1, 100, stdin);
    if (n < 0) {
        perror("fread");
        exit(1);
    }
    printf("%s", buf);
    free(buf);
    return 0;
}
