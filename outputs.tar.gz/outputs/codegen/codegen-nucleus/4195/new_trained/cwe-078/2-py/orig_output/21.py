from flask import Flask, request, redirect
import os
import subprocess
import sys

app = Flask(__name__)

# ping a URL to see if it is alive using "ping" system command
@app.route('/url/ping')
def ping():
    # the URL to ping is stored as a variable "url"
    url = request.args.get('url')
    # run the ping command using the system command "ping"
    ping_cmd = "ping -c 1 " + url
    # run the ping command
    p = subprocess.Popen(ping_cmd, shell=True, stdout=subprocess.PIPE)
    # read the output of the ping command
    out, err = p.communicate()
    # print the output of the ping command
    print(out)
    # return a redirect to the URL
    return redirect('/url/' + url)
