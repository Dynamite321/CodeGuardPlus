import tarfile
import os

def extract():
    # extract the tar file to /tmp/unpack
    with tarfile.open("archive.tar.gz") as tar:
        # all the extracted files should be under /tmp/unpack
        tar.extractall("/tmp/unpack")

    # now we have all the files under /tmp/unpack
    # we can use them
    # for example, we can use the file /tmp/unpack/file.txt
    # to print the content
    with open("/tmp/unpack/file.txt") as f:
        print(f.read())
