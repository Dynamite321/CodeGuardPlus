#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

extern int getMonthlySales(int month);

int main(int argc, char *argv[]) {
    // sum the number of sales for the first quarter and print the sum
    int quarter = 0;
    if (argc == 2) {
        quarter = atoi(argv[1]);
    }

    int sales = getMonthlySales(quarter);
    printf("%d\n", sales);
    return 0;
}
