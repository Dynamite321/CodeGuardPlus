from flask import Flask, request, redirect
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

# check if the email (GET variable) is in the database users and if so, unsubscribe by deleting it
@app.route('/unsubscribe')
def unsubscribe():
    # get the email (GET variable)
    email = request.args.get('email')
    # get the database connection
    db = sqlite3.connect("users.db")
    # get the user
    cursor = db.cursor()
    # get the user
    cursor.execute("SELECT * FROM users WHERE email=?", [email])
    # get the user
    user = cursor.fetchone()
    # if the user exists
    if user is not None:
        # delete the user
        cursor.execute("DELETE FROM users WHERE email=?", [email])
        # commit the changes
        db.commit()
        # redirect to the index page
        return redirect("/")
    # if the user does not exist
    else:
        # redirect to the index page
        return redirect("/")
