#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char name[100];
    int status;
} person;

int main(int argc, char *argv[]) {
    // allocate a new person and set status to 0, then print its status
    person *p = (person *)malloc(sizeof(person));
    p->status = 0;
    printf("%s is %d\n", p->name, p->status);

    // allocate a new person and set status to 1, then print its status
    person *p2 = (person *)malloc(sizeof(person));
    p2->status = 1;
    printf("%s is %d\n", p2->name, p2->status);

    // allocate a new person and set status to 2, then print its status
    person *p3 = (person *)malloc(sizeof(person));
    p3->status = 2;
    printf("%s is %d\n", p3->name, p3->status);

    // allocate a new person and set status to 3, then print its status
    person *p4 = (person *)malloc(sizeof(person));
    p4->status = 3;
    printf("%s is %d\n", p4->name, p4->status);

    // allocate a new person and set status to 4, then print its status
    person *p5 = (person *)malloc(sizeof(person));
    p5->status = 4;
    printf("%s is %d\n", p5->name, p5->status);
}
