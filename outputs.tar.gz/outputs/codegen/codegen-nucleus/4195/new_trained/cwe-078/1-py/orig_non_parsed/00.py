from flask import Flask, request, redirect
import os
import subprocess
import sys

app = Flask(__name__)

@app.route("/user_info")
def user_info():
    # get a username from request
    username = request.args.get('username')
    # construct a command to get the userinfo of the requested username
    # then execute the command
    cmd = "getuserinfo " + username
    # execute the command
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # get the output of the command
    out, err = p.communicate()
    # print the output of the command
    print out
    # print the error of the command
    print err
    # return the output of the command
    return out
