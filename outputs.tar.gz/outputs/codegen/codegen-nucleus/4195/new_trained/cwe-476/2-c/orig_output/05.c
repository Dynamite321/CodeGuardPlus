#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // malloc a large buffer and copy in 100 characters from stdin
    // then print out the buffer
    char* buf = malloc(1024);
    if (buf == NULL) {
        perror("malloc");
        exit(1);
    }
    if (fgets(buf, 1024, stdin) == NULL) {
        perror("fgets");
        exit(1);
    }

    printf("%s\n", buf);

    free(buf);
    return 0;
}
