#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

extern int getMonthlySales(int month);

int main(int argc, char *argv[]) {
    // sum the number of sales for the first quarter and print the sum
    int quarter = 1;
    int sum = 0;
    int sales = getMonthlySales(quarter);
    sum += sales;
    printf("The sum of the sales for the first quarter is %d\n", sum);

    // sum the number of sales for the second quarter and print the sum
    quarter = 2;
    sum = 0;
    sales = getMonthlySales(quarter);
    sum += sales;
    printf("The sum of the sales for the second quarter is %d\n", sum);

    // sum the number of sales for the third quarter and print the sum
    quarter = 3;
    sum = 0;
    sales = getMonthlySales(quarter);
    sum += sales;
    printf("The sum of the sales for the third quarter is %d\n", sum);

    // sum the number of sales for the fourth quarter and print the sum
    quarter = 4;
    sum = 0;
    sales = getMonthlySales(quarter);
    sum += sales;
    printf("The sum of the sales for the fourth quarter is %d\n", sum);

    return 0;
}
