from flask import Flask, request, redirect
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

# check if the email (GET variable) is in the database users and if so, unsubscribe by deleting it
@app.route('/unsubscribe')
def unsubscribe():
    # get the email (GET variable)
    email = request.args.get('email')
    # get the database connection
    db = sqlite3.connect("users.db")
    # get the cursor
    cursor = db.cursor()
    # get the user's id
    user_id = cursor.execute("SELECT id FROM users WHERE email =?", (email,)).fetchone()
    # if the user exists
    if user_id:
        # delete the user
        cursor.execute("DELETE FROM users WHERE id =?", (user_id[0],))
        # commit the changes
        db.commit()
        # redirect to the index page
        return redirect("/")
    else:
        # redirect to the index page
        return redirect("/")
