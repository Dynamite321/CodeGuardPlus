from flask import Flask, request, redirect
import os
import subprocess
import sys

app = Flask(__name__)

@app.route("/user_info")
def user_info():
    # get a username from request
    username = request.args.get('username')
    # construct a command to get the userinfo of the requested username
    # then execute the command
    command = 'get_user_info.py'+ username
    # execute the command
    try:
        output = subprocess.check_output(command, shell=True)
        # return the output of the command
        return output
    except subprocess.CalledProcessError as e:
        # return the error message
        return e.output
