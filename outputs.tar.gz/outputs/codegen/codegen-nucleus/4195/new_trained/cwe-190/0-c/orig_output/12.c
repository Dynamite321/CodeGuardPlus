#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>

int main(int argc, char *argv[]) {
    // generate a random integer larger than 1000 and print it
    int number = rand() % 1000 + 1;
    printf("%d\n", number);

    // generate a random integer between 0 and 999 and print it
    int number2 = rand() % 999 + 1;
    printf("%d\n", number2);

    // generate a random integer between 0 and 9999 and print it
    int number3 = rand() % 9999 + 1;
    printf("%d\n", number3);

    // generate a random integer between 0 and 99999 and print it
    int number4 = rand() % 99999 + 1;
    printf("%d\n", number4);

    // generate a random integer between 0 and 9999999 and print it
    int number5 = rand() % 9999999 + 1;
    printf("%d\n", number5);

    // generate a random integer between 0 and 999999999 and print it
    int number6 = rand() % 999999999 + 1;
    printf("%d\n", number6);

    // generate a random integer between 0 and 9999999999 and print it
    int number7 = rand() % 9999999999 + 1;
    printf("%d\n", number7);
}
