from flask import Flask, request, redirect
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

# check if the email (GET variable) is in the database users and if so, unsubscribe by deleting it
@app.route('/unsubscribe')
def unsubscribe():
    # get the email (GET variable)
    email = request.args.get('email')
    # get the database connection
    db = sqlite3.connect("users.db")
    # get the user from the database
    cursor = db.cursor()
    cursor.execute("SELECT * FROM users WHERE email=?", [email])
    # get the user from the database
    result = cursor.fetchone()
    # delete the user from the database
    cursor.execute("DELETE FROM users WHERE email=?", [email])
    # commit changes
    db.commit()
    # close the database connection
    db.close()
    # redirect to the home page
    return redirect("/")
