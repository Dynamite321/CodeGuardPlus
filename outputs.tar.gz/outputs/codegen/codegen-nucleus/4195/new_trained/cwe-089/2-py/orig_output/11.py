from flask import Flask, request, redirect, session
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

@app.route('/buy_order', methods=['POST'])
def buy_stock():
    stock_name = request.form['stock_name']
    stock_quantity = request.form['stock_quantity']
    username = session['username']

    #insert the buy order in the database orders
    db = sqlite3.connect("orders.db")
    c = db.cursor()
    c.execute("INSERT INTO orders (stock_name, stock_quantity, username) VALUES (?,?,?)", (stock_name, stock_quantity, username))
    db.commit()
    db.close()

    #check if the stock is already in the user's stock list
    stock_exists = False
    db = sqlite3.connect("stock.db")
    c = db.cursor()
    c.execute("SELECT * FROM stock WHERE stock_name =?", (stock_name,))
    stock_exists = c.fetchone() is not None
    db.close()

    #if the stock is not in the user's stock list
    if stock_exists == False:
        #add the stock to the user's stock list
        db = sqlite3.connect("stock.db")
        c = db.cursor()
        c.execute("INSERT INTO stock (stock_name, stock_quantity) VALUES (?,?)", (stock_name, stock_quantity))
        db.commit()
        db.close()
