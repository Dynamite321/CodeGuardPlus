from flask import Flask, request, redirect, session
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

@app.route('/buy_order', methods=['POST'])
def buy_stock():
    stock_name = request.form['stock_name']
    stock_quantity = request.form['stock_quantity']
    username = session['username']

    #insert the buy order in the database orders
    db = sqlite3.connect("orders.db")
    cursor = db.cursor()
    cursor.execute("INSERT INTO orders (username, stock_name, stock_quantity) VALUES (?,?,?)", (username, stock_name, stock_quantity))
    db.commit()

    #check if the user has enough stock
    stock_quantity_available = cursor.execute("SELECT stock_quantity FROM stock WHERE stock_name =?", (stock_name,)).fetchone()[0]
    if stock_quantity_available < stock_quantity:
        return redirect("/buy_stock", code=302)

    #check if the user has enough money
    money_available = cursor.execute("SELECT money FROM user WHERE username =?", (username,)).fetchone()[0]
    if money_available < stock_quantity * 10:
        return redirect("/buy_stock", code=302)
