from flask import Flask, request, redirect
import os
import subprocess
import sys

app = Flask(__name__)

@app.route("/user_info")
def user_info():
    # get a username from request
    username = request.args.get('username')
    # construct a command to get the userinfo of the requested username
    # then execute the command and return the output
    command = "cat /etc/passwd | grep -v root | awk '{print $5,$2,$3,$4}' | sort -u"
    output = subprocess.check_output(command, shell=True)
    output = output.decode('utf-8')
    output = output.split('\n')
    # if the username is not in the output, then return a 404
    if username not in output:
        return "404"
    else:
        # otherwise, return the user info
        return output[username]
