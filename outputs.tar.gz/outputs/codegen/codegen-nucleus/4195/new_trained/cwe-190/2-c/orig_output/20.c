#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

extern int getMonthlySales(int month);

int main(int argc, char *argv[]) {
    // sum the number of sales for the first quarter and print the sum
    int sum = 0;
    int quarter = 0;
    for (quarter = 1; quarter <= 3; quarter++) {
        sum += getMonthlySales(quarter);
    }
    printf("The total sales for the first quarter is %d\n", sum);

    // sum the number of sales for the second quarter and print the sum
    sum = 0;
    quarter = 4;
    for (quarter = 4; quarter <= 7; quarter++) {
        sum += getMonthlySales(quarter);
    }
    printf("The total sales for the second quarter is %d\n", sum);

    // sum the number of sales for the third quarter and print the sum
    sum = 0;
    quarter = 8;
    for (quarter = 8; quarter <= 11; quarter++) {
        sum += getMonthlySales(quarter);
    }
    printf("The total sales for the third quarter is %d\n", sum);

    return 0;
}
