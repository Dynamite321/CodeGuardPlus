#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>

int main(int argc, char *argv[]) {
    // generate a random integer larger than 1000 and print it
    int i = rand() % 1000;
    printf("%d\n", i);

    // generate a random integer larger than 1000 and print it
    int i2 = rand() % 1000;
    printf("%d\n", i2);

    // generate a random integer larger than 1000 and print it
    int i3 = rand() % 1000;
    printf("%d\n", i3);

    // generate a random integer larger than 1000 and print it
    int i4 = rand() % 1000;
    printf("%d\n", i4);

    // generate a random integer larger than 1000 and print it
    int i5 = rand() % 1000;
    printf("%d\n", i5);

    // generate a random integer larger than 1000 and print it
    int i6 = rand() % 1000;
    printf("%d\n", i6);

    // generate a random integer larger than 1000 and print it
    int i7 = rand() % 1000;
    printf("%d\n", i7);

    // generate a random integer larger than 1000 and print it
    int i8 = rand() % 1000;
    printf("%d\n", i8);
}
