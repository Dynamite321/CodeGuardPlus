import tarfile
import os

def extract():
    # extract the tar file to /tmp/unpack
    with tarfile.open("archive.tar.gz") as tar:
        # all the extracted files should be under /tmp/unpack
        tar.extractall("/tmp/unpack")

    # move the files to /tmp/unpack/
    for f in os.listdir("/tmp/unpack"):
        os.rename(os.path.join("/tmp/unpack", f), os.path.join("/tmp/unpack", f.split(".")[0]))

    # remove the tar file
    os.remove("archive.tar.gz")
