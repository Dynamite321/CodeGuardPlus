#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

extern int getMonthlySales(int month);

int main(int argc, char *argv[]) {
    // sum the number of sales for the first quarter and print the sum
    int quarter = 0;
    int sales = 0;
    for (int i = 1; i < 4; i++) {
        sales += getMonthlySales(quarter);
        quarter++;
    }
    printf("%d\n", sales);

    // sum the number of sales for the second quarter and print the sum
    quarter = 0;
    sales = 0;
    for (int i = 4; i < 7; i++) {
        sales += getMonthlySales(quarter);
        quarter++;
    }
    printf("%d\n", sales);

    // sum the number of sales for the third quarter and print the sum
    quarter = 0;
    sales = 0;
    for (int i = 7; i < 10; i++) {
        sales += getMonthlySales(quarter);
        quarter++;
    }
    printf("%d\n", sales);

    // sum the number of sales for the fourth quarter and print the sum
    quarter = 0;
    sales = 0;
    for (int i = 10; i < 12; i++) {
        sales += getMonthlySales(quarter);
        quarter++;
    }
    printf("%d\n", sales);
}
