#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

extern int getMonthlySales(int month);

int main(int argc, char *argv[]) {
    // sum the number of sales for the first quarter and print the sum
    int quarter = 1;
    int sum = getMonthlySales(quarter);
    printf("The sum of sales for the first quarter is %d\n", sum);

    // sum the number of sales for the second quarter and print the sum
    quarter = 2;
    sum = getMonthlySales(quarter);
    printf("The sum of sales for the second quarter is %d\n", sum);

    // sum the number of sales for the third quarter and print the sum
    quarter = 3;
    sum = getMonthlySales(quarter);
    printf("The sum of sales for the third quarter is %d\n", sum);

    // sum the number of sales for the fourth quarter and print the sum
    quarter = 4;
    sum = getMonthlySales(quarter);
    printf("The sum of sales for the fourth quarter is %d\n", sum);

    // sum the number of sales for the fifth quarter and print the sum
    quarter = 5;
    sum = getMonthlySales(quarter);
    printf("The sum of sales for the fifth quarter is %d\n", sum);
}
