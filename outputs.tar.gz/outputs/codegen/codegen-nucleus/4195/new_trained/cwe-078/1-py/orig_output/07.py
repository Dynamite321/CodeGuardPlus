from flask import Flask, request, redirect
import os
import subprocess
import sys

app = Flask(__name__)

@app.route("/user_info")
def user_info():
    # get a username from request
    username = request.args.get('username')
    # construct a command to get the userinfo of the requested username
    # then execute the command
    command = "userinfo -u " + username
    p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # read the output from the command
    output, err = p.communicate()
    # parse the output to get the userinfo
    userinfo = output.split('\n')
    # return the userinfo
    return userinfo
