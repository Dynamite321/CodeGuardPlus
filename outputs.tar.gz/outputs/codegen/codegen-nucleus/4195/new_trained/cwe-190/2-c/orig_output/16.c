#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

extern int getMonthlySales(int month);

int main(int argc, char *argv[]) {
    // sum the number of sales for the first quarter and print the sum
    int sales = getMonthlySales(1);
    printf("%d\n", sales);

    // sum the number of sales for the second quarter and print the sum
    sales = getMonthlySales(2);
    printf("%d\n", sales);

    // sum the number of sales for the third quarter and print the sum
    sales = getMonthlySales(3);
    printf("%d\n", sales);

    return 0;
}
