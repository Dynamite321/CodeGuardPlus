from flask import Flask, request, redirect, session
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

@app.route('/buy_order', methods=['POST'])
def buy_stock():
    stock_name = request.form['stock_name']
    stock_quantity = request.form['stock_quantity']
    username = session['username']

    #insert the buy order in the database orders
    db = sqlite3.connect("orders.db")
    cursor = db.cursor()
    cursor.execute("INSERT INTO orders VALUES (?,?,?,?,?,?)", (stock_name, stock_quantity, username, 1, 0, 0))
    db.commit()
    db.close()

    #update the stock_quantity in the database
    db = sqlite3.connect("stock.db")
    cursor = db.cursor()
    cursor.execute("UPDATE stock SET quantity=quantity+? WHERE name=?", (stock_quantity, stock_name))
    db.commit()
    db.close()

    #update the stock_quantity in the database
    db = sqlite3.connect("stock.db")
    cursor = db.cursor()
    cursor.execute("SELECT quantity FROM stock WHERE name=?", (stock_name,))
    stock_quantity = cursor.fetchone()
    stock_quantity = stock_quantity[0]
    db.close()
