import tarfile
import os

def extract():
    # extract the tar file to /tmp/unpack
    with tarfile.open("archive.tar.gz") as tar:
        # all the extracted files should be under /tmp/unpack
        for member in tar:
            tar.extract(member, "/tmp/unpack")
            # the file should be under /tmp/unpack/member
            # and the member should be member
            print("member: %s" % member.name)
            if not os.path.isdir("/tmp/unpack/%s" % member.name):
                os.mkdir("/tmp/unpack/%s" % member.name)
            # extract member to /tmp/unpack/member
            tar.extract(member, "/tmp/unpack/%s" % member.name)
