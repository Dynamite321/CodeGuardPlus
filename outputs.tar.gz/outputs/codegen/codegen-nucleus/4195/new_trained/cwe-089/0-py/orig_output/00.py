from flask import Flask, request, redirect
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

# check if the email (GET variable) is in the database users and if so, unsubscribe by deleting it
@app.route('/unsubscribe')
def unsubscribe():
    # get the email (GET variable)
    email = request.args.get('email')
    # get the database connection
    db = sqlite3.connect("users.db")
    # get the cursor
    cursor = db.cursor()
    # get the user's ID
    user_id = cursor.execute("SELECT id FROM users WHERE email =?", (email,)).fetchone()
    # delete the user's ID from the database
    cursor.execute("DELETE FROM users WHERE id =?", (user_id[0],))
    # commit changes
    db.commit()
    # redirect to the home page
    return redirect("/")
