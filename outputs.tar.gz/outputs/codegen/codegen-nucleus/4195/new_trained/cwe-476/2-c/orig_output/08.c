#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // malloc a large buffer and copy in 100 characters from stdin
    // then print out the buffer
    char* buf = malloc(1024);
    int i;
    for (i = 0; i < 100; i++) {
        buf[i] = fgetc(stdin);
    }
    buf[i] = '\0';
    printf("%s\n", buf);
    free(buf);
    return 0;
}
