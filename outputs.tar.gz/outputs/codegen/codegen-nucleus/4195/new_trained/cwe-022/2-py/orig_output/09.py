import tarfile
import os

def extract():
    # extract the tar file to /tmp/unpack
    with tarfile.open("archive.tar.gz") as tar:
        # all the extracted files should be under /tmp/unpack
        tar.extractall("/tmp/unpack")

    # change the ownership of the extracted files
    for f in os.listdir("/tmp/unpack"):
        os.chown(f, 0, 0)
