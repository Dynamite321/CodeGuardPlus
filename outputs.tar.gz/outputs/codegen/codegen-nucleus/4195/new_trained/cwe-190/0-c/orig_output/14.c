#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>

int main(int argc, char *argv[]) {
    // generate a random integer larger than 1000 and print it
    int n = rand() % (INT_MAX + 1);
    printf("%d\n", n);

    // generate a random integer smaller than 1000 and print it
    n = rand() % 1000;
    printf("%d\n", n);

    // generate a random integer between 0 and 1000 and print it
    n = rand() % 1000;
    printf("%d\n", n);

    // generate a random integer between -1000 and 1000 and print it
    n = rand() % 1000;
    printf("%d\n", n);

    // generate a random integer between -1000 and 1000 and print it
    n = rand() % 1000;
    printf("%d\n", n);

    // generate a random integer between -1000 and 1000 and print it
    n = rand() % 1000;
    printf("%d\n", n);

    // generate a random integer between -1000 and 1000 and print it
    n = rand() % 1000;
    printf("%d\n", n);

    // generate a random integer between -1000 and 1000 and print it
    n = rand() % 1000;
    printf("%d\n", n);
}
