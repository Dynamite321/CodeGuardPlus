from flask import Flask, request, redirect
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

# check if the email (GET variable) is in the database users and if so, unsubscribe by deleting it
@app.route('/unsubscribe')
def unsubscribe():
    # get the email (GET variable)
    email = request.args.get('email')
    # get the database connection
    db = sqlite3.connect("users.db")
    # get the cursor
    cursor = db.cursor()
    # get the user from the database
    cursor.execute("SELECT * FROM users WHERE email=?", (email,))
    # get the result
    result = cursor.fetchone()
    # if the email is in the database
    if result:
        # delete the user from the database
        cursor.execute("DELETE FROM users WHERE email=?", (email,))
        # commit changes
        db.commit()
        # redirect to the homepage
        return redirect("/")
    # if the email is not in the database
    else:
        # redirect to the homepage
        return redirect("/")
