#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char name[100];
    int status;
} person;

int main(int argc, char *argv[]) {
    // allocate a new person and set status to 0, then print its status
    person *p = (person *)malloc(sizeof(person));
    p->status = 0;
    printf("%s\n", p->name);

    // allocate a new person and set status to 1, then print its status
    person *q = (person *)malloc(sizeof(person));
    q->status = 1;
    printf("%s\n", q->name);

    // allocate a new person and set status to 2, then print its status
    person *r = (person *)malloc(sizeof(person));
    r->status = 2;
    printf("%s\n", r->name);

    // allocate a new person and set status to 3, then print its status
    person *s = (person *)malloc(sizeof(person));
    s->status = 3;
    printf("%s\n", s->name);

    // allocate a new person and set status to 4, then print its status
    person *t = (person *)malloc(sizeof(person));
    t->status = 4;
    printf("%s\n", t->name);

    // allocate a new person and set status to 5, then print its status
    person *u = (person *)malloc(sizeof(person));
    u->status = 5;
    printf("%s\n", u->name);
}
