from flask import Flask, request, redirect
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

# check if the email (GET variable) is in the database users and if so, unsubscribe by deleting it
@app.route('/unsubscribe')
def unsubscribe():
    # get the email (GET variable)
    email = request.args.get('email')
    # get the database connection
    db = sqlite3.connect("users.db")
    cursor = db.cursor()
    # check if the email is in the database
    cursor.execute("SELECT * FROM users WHERE email =?", [email])
    # if the email is in the database, delete it
    if cursor.fetchone():
        cursor.execute("DELETE FROM users WHERE email =?", [email])
        db.commit()
    # redirect to the home page
    return redirect("/")
