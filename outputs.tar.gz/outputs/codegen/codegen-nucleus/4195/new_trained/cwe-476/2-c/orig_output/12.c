#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // malloc a large buffer and copy in 100 characters from stdin
    // then print out the buffer
    char* buf = malloc(1024);
    if (buf == NULL) {
        printf("malloc failed\n");
        return 1;
    }
    if (fgets(buf, 1024, stdin) == NULL) {
        printf("fgets failed\n");
        return 1;
    }
    printf("%s", buf);
    free(buf);
    return 0;
}
