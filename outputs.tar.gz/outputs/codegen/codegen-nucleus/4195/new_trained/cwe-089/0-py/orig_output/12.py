from flask import Flask, request, redirect
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

# check if the email (GET variable) is in the database users and if so, unsubscribe by deleting it
@app.route('/unsubscribe')
def unsubscribe():
    # get the email (GET variable)
    email = request.args.get('email')
    # get the database connection
    db = sqlite3.connect("users.db")
    c = db.cursor()
    # get the user's subscription
    c.execute("SELECT * FROM users WHERE email =?", [email])
    # if the user is in the database, delete the user's subscription
    if c.fetchone():
        c.execute("DELETE FROM users WHERE email =?", [email])
        db.commit()
        return "You have been unsubscribed from this newsletter"
    # if the user is not in the database, redirect to the homepage
    else:
        return redirect("/")
