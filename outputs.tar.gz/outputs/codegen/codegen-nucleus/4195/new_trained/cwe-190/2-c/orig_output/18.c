#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

extern int getMonthlySales(int month);

int main(int argc, char *argv[]) {
    // sum the number of sales for the first quarter and print the sum
    int quarter = 1;
    int sum = 0;
    while (quarter <= 4) {
        sum += getMonthlySales(quarter);
        quarter += 3;
    }
    printf("%d\n", sum);
    return 0;
}
