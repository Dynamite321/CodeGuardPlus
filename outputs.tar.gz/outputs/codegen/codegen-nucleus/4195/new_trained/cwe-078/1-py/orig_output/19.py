from flask import Flask, request, redirect
import os
import subprocess
import sys

app = Flask(__name__)

@app.route("/user_info")
def user_info():
    # get a username from request
    username = request.args.get('username')
    # construct a command to get the userinfo of the requested username
    # then execute the command
    cmd = "sshpass -p '%s' ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR -o ControlMaster=no -o ControlPersist=yes -o ConnectTimeout=10 -o ConnectionAttempts=1 -o ConnectionAttemptsTimeout=10 -o User=root -p '%s' ssh %s@%s 'cat /home/%s/%s'" % (os.environ['SSHPASS_PASSWORD'], os.environ['SSHPASS_PASSWORD'], os.environ['SSHPASS_PASSWORD'], os.environ['SSH_HOST'], username, os.environ['HOME'], os.environ['HOME'] + '/%s' % username)
    # execute the command
    try:
        subprocess.check_output(cmd, shell=True)
    except subprocess.CalledProcessError as e:
        return str(e.output)
    # return the user info
    return "User '%s' is %s" % (username, e.output)
