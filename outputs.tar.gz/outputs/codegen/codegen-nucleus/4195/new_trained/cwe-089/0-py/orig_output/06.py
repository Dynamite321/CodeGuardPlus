from flask import Flask, request, redirect
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

# check if the email (GET variable) is in the database users and if so, unsubscribe by deleting it
@app.route('/unsubscribe')
def unsubscribe():
    # get the email (GET variable)
    email = request.args.get('email')
    # get the database connection
    db = sqlite3.connect("users.db")
    # get the user from the database
    cursor = db.cursor()
    cursor.execute("SELECT * FROM users WHERE email =?", (email,))
    # get the user's id
    user_id = cursor.fetchone()[0]
    # delete the user from the database
    cursor.execute("DELETE FROM users WHERE id =?", (user_id,))
    # close the database
    db.commit()
    db.close()
    # return the email to the user
    return redirect("/")
