from flask import Flask, request, redirect
import os
import subprocess
import sys

app = Flask(__name__)

# ping a URL to see if it is alive using "ping" system command
@app.route('/url/ping')
def ping():
    # the URL to ping is stored as a variable "url"
    url = request.args.get('url')
    # run the ping command using the system command "ping"
    cmd = "ping -c 1 " + url
    # run the command
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # get the output
    output, errors = p.communicate()
    # check for errors
    if errors:
        # print the error message
        print(errors)
        # return an error message
        return 'ping error'
    # check for output
    if output:
        # print the output
        print(output)
        # return the output
        return output
    # return an error message
    return 'ping error'
