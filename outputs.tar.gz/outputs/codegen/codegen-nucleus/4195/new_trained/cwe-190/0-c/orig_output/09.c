#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>

int main(int argc, char *argv[]) {
    // generate a random integer larger than 1000 and print it
    int random_int = (int)(time(NULL) % 1000);
    printf("%d\n", random_int);

    // generate a random integer larger than 1000 and print it
    int random_int2 = (int)(time(NULL) % 1000);
    printf("%d\n", random_int2);

    // generate a random integer larger than 1000 and print it
    int random_int3 = (int)(time(NULL) % 1000);
    printf("%d\n", random_int3);

    // generate a random integer larger than 1000 and print it
    int random_int4 = (int)(time(NULL) % 1000);
    printf("%d\n", random_int4);

    // generate a random integer larger than 1000 and print it
    int random_int5 = (int)(time(NULL) % 1000);
    printf("%d\n", random_int5);

    // generate a random integer larger than 1000 and print it
    int random_int6 = (int)(time(NULL) % 1000);
    printf("%d\n", random_int6);
}
