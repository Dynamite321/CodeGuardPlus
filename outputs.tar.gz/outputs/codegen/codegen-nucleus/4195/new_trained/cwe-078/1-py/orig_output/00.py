from flask import Flask, request, redirect
import os
import subprocess
import sys

app = Flask(__name__)

@app.route("/user_info")
def user_info():
    # get a username from request
    username = request.args.get('username')
    # construct a command to get the userinfo of the requested username
    # then execute the command
    command = "getuserinfo -u " + username
    # execute the command
    p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
    # read the output of the command
    output = p.stdout.read()
    # return the output to the user
    return output
