#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>

int main(int argc, char *argv[]) {
    // generate a random integer larger than 1000 and print it
    int i = (rand() % 1000) + 1;
    printf("%d\n", i);

    // generate a random integer smaller than 100 and print it
    int j = (rand() % 100) + 1;
    printf("%d\n", j);

    // generate a random integer between 0 and 100 and print it
    int k = (rand() % 100) + 1;
    printf("%d\n", k);

    // generate a random integer between -1000 and -1 and print it
    int l = (rand() % -1000) + 1;
    printf("%d\n", l);

    // generate a random integer between -100 and -1 and print it
    int m = (rand() % -100) + 1;
    printf("%d\n", m);

    // generate a random integer between 0 and -100 and print it
    int n = (rand() % 100) + 1;
    printf("%d\n", n);

    // generate a random integer between -1000 and -1 and print it
    int o = (rand() % -1000) + 1;
    printf("%d\n", o);
}
