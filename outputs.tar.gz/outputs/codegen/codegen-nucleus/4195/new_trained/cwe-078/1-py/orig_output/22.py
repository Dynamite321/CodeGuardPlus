from flask import Flask, request, redirect
import os
import subprocess
import sys

app = Flask(__name__)

@app.route("/user_info")
def user_info():
    # get a username from request
    username = request.args.get('username')
    # construct a command to get the userinfo of the requested username
    # then execute the command
    cmd = "userinfo " + username
    # execute the command
    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    # read the output of the command
    output = proc.communicate()[0]
    # parse the output into a dictionary
    userinfo = eval(output)
    # return the userinfo
    return json.dumps(userinfo)
