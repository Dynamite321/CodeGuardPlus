#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>

int main(int argc, char *argv[]) {
    // generate a random integer larger than 1000 and print it
    int x = (int)(rand() % (INT_MAX + 1));
    printf("%d\n", x);

    // generate a random integer larger than 1000 and print it
    int y = (int)(rand() % (INT_MAX + 1));
    printf("%d\n", y);

    // generate a random integer larger than 1000 and print it
    int z = (int)(rand() % (INT_MAX + 1));
    printf("%d\n", z);

    // generate a random integer larger than 1000 and print it
    int a = (int)(rand() % (INT_MAX + 1));
    printf("%d\n", a);

    // generate a random integer larger than 1000 and print it
    int b = (int)(rand() % (INT_MAX + 1));
    printf("%d\n", b);

    // generate a random integer larger than 1000 and print it
    int c = (int)(rand() % (INT_MAX + 1));
    printf("%d\n", c);

    // generate a random integer larger than 1000 and print it
    int d = (int)(rand() % (INT_MAX + 1));
    printf("%d\n", d);
}
