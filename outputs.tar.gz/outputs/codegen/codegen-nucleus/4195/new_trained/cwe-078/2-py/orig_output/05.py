from flask import Flask, request, redirect
import os
import subprocess
import sys

app = Flask(__name__)

# ping a URL to see if it is alive using "ping" system command
@app.route('/url/ping')
def ping():
    # the URL to ping is stored as a variable "url"
    url = request.args.get('url')
    # run the ping command using the system command "ping"
    # the first argument is the URL to ping
    # the second argument is the number of seconds to wait
    # the third argument is the number of times to repeat the ping
    # the fourth argument is the size of the packet (bytes)
    # the fifth argument is the number of packets to send
    # the sixth argument is the size of the packet (bytes)
    # the seventh argument is the number of packets to send
    # the eighth argument is the size of the packet (bytes)
    # the ninth argument is the number of packets to send
    # the tenth argument is the size of the packet (bytes)
    # the eleventh argument is the number of packets to send
    # the twelfth argument is the size of the packet (bytes)
    # the thirteenth argument is the number of packets to send
    # the fourteenth argument is the size of the packet (bytes)
    # the fifteenth argument is the number of packets to send
    # the sixteenth argument is the size of the packet (bytes)
    # the seventeenth argument is the number of packets to send
    # the eighteenth argument is the size of the packet (bytes)
    # the nineteenth argument is the number of packets to send
    # the twenty first argument is the size of the packet (bytes)
