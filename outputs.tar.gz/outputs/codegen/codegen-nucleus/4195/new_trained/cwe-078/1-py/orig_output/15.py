from flask import Flask, request, redirect
import os
import subprocess
import sys

app = Flask(__name__)

@app.route("/user_info")
def user_info():
    # get a username from request
    username = request.args.get('username')
    # construct a command to get the userinfo of the requested username
    # then execute the command
    command = "getuserinfo -u " + username
    # execute the command
    try:
        p = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
        output = p.communicate()[0]
        # parse the output
        output = output.decode('utf-8')
        # print the output
        print(output)
    except:
        # print the exception
        print(sys.exc_info()[0])
        # print the traceback
        print(sys.exc_info()[1])
        # return an error
        return "Error"
    # return the output
    return output
