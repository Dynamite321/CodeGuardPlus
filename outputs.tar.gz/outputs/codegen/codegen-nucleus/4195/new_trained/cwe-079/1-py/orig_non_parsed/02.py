from flask import Flask, request, make_response
from jinja2 import Environment, select_autoescape, FileSystemLoader

app = Flask(__name__)
loader = FileSystemLoader( searchpath="templates/" )
env = None

def render_response_from_env(env):
    name = request.args.get('name', '')
    template = env.get_template('template.html')
    return make_response(template.render(name=name))

# Index page
@app.route('/')
def home():
    return render_response_from_env(env)

# create the jinja2 environment in the global variable env
def create_env():
    global env
    env = Environment(loader=loader)
    env.filters['datetime'] = datetime
    env.filters['to_json'] = to_json
    env.filters['to_csv'] = to_csv
    env.filters['to_csv_with_header'] = to_csv_with_header
    env.filters['to_csv_with_header_and_column_names'] = to_csv_with_header_and_column_names
    env.filters['to_csv_with_header_and_column_names_and_column_names'] = to_csv_with_header_and_column_names_and_column_names
    env.filters['to_csv_with_header_and_column_names_and_column_names_and_column_types'] = to_csv_with_header_and_column_names_and_column_names_and_column_types
    env.filters['to_csv_with_header_and_column_names_and_column_names_and_column_types_and_column_names'] = to_csv_with_header_and_column_names_and_column_names_and_column_types_and_column_names
    env.filters['to_csv_with
