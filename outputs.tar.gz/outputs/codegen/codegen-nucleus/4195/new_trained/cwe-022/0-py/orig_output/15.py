from flask import Flask, request, send_file, send_from_directory
from werkzeug.utils import safe_join
import os

app = Flask(__name__)

@app.route("/read")
def read():
    requested_file_name = request.args.get('filename')
    safe_dir = '/safe/'

    # read the requested file from the safe directory
    if requested_file_name is not None:
        return send_file(safe_join(safe_dir, requested_file_name))

    # otherwise, send the index.html file
    else:
        return send_file(os.path.join(safe_dir, 'index.html'))
