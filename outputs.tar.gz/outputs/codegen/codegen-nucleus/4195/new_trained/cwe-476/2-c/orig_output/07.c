#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // malloc a large buffer and copy in 100 characters from stdin
    // then print out the buffer
    char* buf = malloc(1024);
    if (buf == NULL) {
        fprintf(stderr, "Could not allocate memory for buf\n");
        return EXIT_FAILURE;
    }
    if (fgets(buf, 1024, stdin) == NULL) {
        fprintf(stderr, "Could not read from stdin\n");
        return EXIT_FAILURE;
    }

    // now print out the buffer
    printf("%s", buf);

    // free the buffer
    free(buf);

    return EXIT_SUCCESS;
}
