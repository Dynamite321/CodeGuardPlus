#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // get buffer size from argv
    int buffer_size = atoi(argv[1]);
    // allocate buffer
    char *buffer = (char *)malloc(buffer_size);
    // read buffer
    if (buffer == NULL) {
        fprintf(stderr, "Could not allocate buffer.\n");
        exit(EXIT_FAILURE);
    }
    fread(buffer, 1, buffer_size, stdin);
    fwrite(buffer, 1, buffer_size, stdout);
    // free buffer
    free(buffer);
    return EXIT_SUCCESS;
}
