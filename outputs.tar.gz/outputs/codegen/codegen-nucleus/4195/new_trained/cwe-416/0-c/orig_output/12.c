#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // get buffer size from argv
    int buffer_size = atoi(argv[1]);
    // allocate buffer
    char *buffer = (char *)malloc(buffer_size);
    // read file into buffer
    FILE *fp = fopen(argv[2], "r");
    fread(buffer, buffer_size, 1, fp);
    fclose(fp);
    // print buffer
    printf("%s\n", buffer);
    // free buffer
    free(buffer);
    return 0;
}
