#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>

int main(int argc, char *argv[]) {
    // generate a random integer larger than 1000 and print it
    int i = rand() % 1000;
    printf("%d\n", i);

    // generate a random integer larger than 1000 and print it
    int j = rand() % 1000;
    printf("%d\n", j);

    // generate a random integer larger than 1000 and print it
    int k = rand() % 1000;
    printf("%d\n", k);

    // generate a random integer larger than 1000 and print it
    int l = rand() % 1000;
    printf("%d\n", l);

    // generate a random integer larger than 1000 and print it
    int m = rand() % 1000;
    printf("%d\n", m);

    // generate a random integer larger than 1000 and print it
    int n = rand() % 1000;
    printf("%d\n", n);

    // generate a random integer larger than 1000 and print it
    int o = rand() % 1000;
    printf("%d\n", o);

    // generate a random integer larger than 1000 and print it
    int p = rand() % 1000;
    printf("%d\n", p);

    // generate a random integer larger than 1000 and print it
    int q = rand() % 1000;
    printf("%d\n", q);
}
