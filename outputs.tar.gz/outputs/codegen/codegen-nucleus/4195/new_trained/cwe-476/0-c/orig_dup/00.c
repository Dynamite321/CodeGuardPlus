#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char name[100];
    int status;
} person;

int main(int argc, char *argv[]) {
    // allocate a new person and set status to 0, then print its status
    person *p = (person *)malloc(sizeof(person));
    p->status = 0;
    printf("%s: %d\n", p->name, p->status);
    return 0;
}
