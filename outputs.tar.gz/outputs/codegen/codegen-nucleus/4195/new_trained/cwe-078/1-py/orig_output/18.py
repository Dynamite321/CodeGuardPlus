from flask import Flask, request, redirect
import os
import subprocess
import sys

app = Flask(__name__)

@app.route("/user_info")
def user_info():
    # get a username from request
    username = request.args.get('username')
    # construct a command to get the userinfo of the requested username
    # then execute the command
    cmd = "sshpass -p 'password' ssh -o StrictHostKeyChecking=no " + \
          "root@" + username + " 'cat /etc/passwd | grep " + username + "'"
    # execute the command
    process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    # read the output of the command
    output = process.communicate()[0]
    # get the output as a list of lines
    output = output.split('\n')
    # get the first line of the output
    first_line = output[0]
    # get the username from the first line
    username = first_line.split(':')[0]
