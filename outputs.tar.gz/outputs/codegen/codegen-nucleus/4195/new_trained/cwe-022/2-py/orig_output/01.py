import tarfile
import os

def extract():
    # extract the tar file to /tmp/unpack
    with tarfile.open("archive.tar.gz") as tar:
        # all the extracted files should be under /tmp/unpack
        # so we can use tar.getnames() to get a list of files
        for name in tar.getnames():
            # we can use tar.extractfile() to get a file-like object
            # and then use it to read the file
            with tar.extractfile(name) as f:
                # we can use f.read() to read the file
                # we could also use f.readlines()
                print(f.read())
