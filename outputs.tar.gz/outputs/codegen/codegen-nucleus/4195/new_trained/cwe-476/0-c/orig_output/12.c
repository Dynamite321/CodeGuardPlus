#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char name[100];
    int status;
} person;

int main(int argc, char *argv[]) {
    // allocate a new person and set status to 0, then print its status
    person *p = (person *)malloc(sizeof(person));
    p->status = 0;
    printf("%s\n", p->name);

    // allocate a new person and set status to 1, then print its status
    person *q = (person *)malloc(sizeof(person));
    q->status = 1;
    printf("%s\n", q->name);

    // allocate a new person and set status to 2, then print its status
    person *r = (person *)malloc(sizeof(person));
    r->status = 2;
    printf("%s\n", r->name);

    // free the person structure and print its status
    free(p);
    printf("%s\n", p->name);

    // free the person structure and print its status
    free(q);
    printf("%s\n", q->name);

    // free the person structure and print its status
    free(r);
    printf("%s\n", r->name);

    return 0;
}
