#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>

int main(int argc, char *argv[]) {
    // generate a random integer larger than 1000 and print it
    int x = (rand() % 1000) + 1;
    printf("%d\n", x);

    // generate a random integer larger than 1000 and print it
    int y = (rand() % 1000) + 1;
    printf("%d\n", y);

    // generate a random integer larger than 1000 and print it
    int z = (rand() % 1000) + 1;
    printf("%d\n", z);

    // generate a random integer larger than 1000 and print it
    int w = (rand() % 1000) + 1;
    printf("%d\n", w);

    // generate a random integer larger than 1000 and print it
    int a = (rand() % 1000) + 1;
    printf("%d\n", a);

    // generate a random integer larger than 1000 and print it
    int b = (rand() % 1000) + 1;
    printf("%d\n", b);

    // generate a random integer larger than 1000 and print it
    int c = (rand() % 1000) + 1;
    printf("%d\n", c);

    // generate a random integer larger than 1000 and print it
    int d = (rand() % 1000) + 1;
    printf("%d\n", d);
}
