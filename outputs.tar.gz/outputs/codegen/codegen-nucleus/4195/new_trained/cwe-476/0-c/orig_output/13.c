#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char name[100];
    int status;
} person;

int main(int argc, char *argv[]) {
    // allocate a new person and set status to 0, then print its status
    person *p = (person *)malloc(sizeof(person));
    p->status = 0;
    printf("%s: %d\n", p->name, p->status);

    // allocate a new person and set status to 1, then print its status
    person *p2 = (person *)malloc(sizeof(person));
    p2->status = 1;
    printf("%s: %d\n", p2->name, p2->status);

    // free the first person and print its status
    free(p);
    printf("%s: %d\n", p->name, p->status);

    // free the second person and print its status
    free(p2);
    printf("%s: %d\n", p2->name, p2->status);

    return 0;
}
