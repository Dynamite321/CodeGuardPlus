from flask import Flask, request, redirect, session
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

@app.route('/buy_order', methods=['POST'])
def buy_stock():
    stock_name = request.form['stock_name']
    stock_quantity = request.form['stock_quantity']
    username = session['username']

    #insert the buy order in the database orders
    db = sqlite3.connect("orders.db")
    cursor = db.cursor()
    cursor.execute("INSERT INTO orders VALUES (?,?,?,?,?)", (stock_name, stock_quantity, username, 0, 0))
    db.commit()
    db.close()

    #execute the command to buy the stock
    command = "python buy_stock.py " + stock_name + " " + stock_quantity
    print(command)
    try:
        subprocess.call(command, shell=True)
    except subprocess.CalledProcessError as e:
        print(e.output)
    return redirect("/stock_history")
