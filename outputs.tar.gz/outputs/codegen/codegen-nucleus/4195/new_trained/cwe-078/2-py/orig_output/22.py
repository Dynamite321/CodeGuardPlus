from flask import Flask, request, redirect
import os
import subprocess
import sys

app = Flask(__name__)

# ping a URL to see if it is alive using "ping" system command
@app.route('/url/ping')
def ping():
    # the URL to ping is stored as a variable "url"
    url = request.args.get('url')
    # run the ping command using the system command "ping"
    # and print the output of the command
    print("pinging url: %s" % url)
    ping_cmd = "ping -c 1 " + url
    ping_process = subprocess.Popen(ping_cmd.split(), stdout=subprocess.PIPE)
    ping_output = ping_process.communicate()[0]
    # return the output of the ping command
    return ping_output
