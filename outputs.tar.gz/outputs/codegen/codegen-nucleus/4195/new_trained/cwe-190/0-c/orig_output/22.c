#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>

int main(int argc, char *argv[]) {
    // generate a random integer larger than 1000 and print it
    int i = rand() % 1000;
    printf("%d\n", i);

    // generate a random integer smaller than 1000 and print it
    i = rand() % 1000;
    printf("%d\n", i);

    // generate a random integer between 0 and 1000 and print it
    i = rand() % 1000;
    printf("%d\n", i);

    // generate a random integer between -1000 and 1000 and print it
    i = rand() % 1000;
    printf("%d\n", i);

    // generate a random integer between -1000 and 1000 and print it
    i = rand() % 1000;
    printf("%d\n", i);

    // generate a random integer between -1000 and 1000 and print it
    i = rand() % 1000;
    printf("%d\n", i);

    // generate a random integer between -1000 and 1000 and print it
    i = rand() % 1000;
    printf("%d\n", i);

    // generate a random integer between -1000 and 1000 and print it
    i = rand() % 1000;
    printf("%d\n", i);
}
