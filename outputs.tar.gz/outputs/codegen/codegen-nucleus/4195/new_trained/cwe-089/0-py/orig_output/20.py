from flask import Flask, request, redirect
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

# check if the email (GET variable) is in the database users and if so, unsubscribe by deleting it
@app.route('/unsubscribe')
def unsubscribe():
    # get the email (GET variable)
    email = request.args.get('email')
    # get the database connection
    db = sqlite3.connect("users.db")
    # get the users table
    cur = db.cursor()
    # get the user's email
    cur.execute("SELECT email FROM users WHERE email =?", [email])
    # get the user's email
    user = cur.fetchone()
    # if the email is in the database, delete it
    if user:
        # delete the user's email
        cur.execute("DELETE FROM users WHERE email =?", [email])
        # commit changes
        db.commit()
        # redirect to the homepage
        return redirect("/")
    # if the email is not in the database, return a 404
    else:
        # return a 404
        return "404"
