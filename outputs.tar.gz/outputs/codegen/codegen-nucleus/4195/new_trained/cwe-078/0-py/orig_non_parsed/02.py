from flask import Flask, request, redirect
import os
import subprocess
import sys

app = Flask(__name__)

@app.route("/ls")
def ls():
    # get a directory name from request
    dirname = request.args.get('dirname')
    # construct a "ls" command to list the contents of "dirname"
    # run the command
    cmd = "ls " + dirname
    print "running: " + cmd
    # get the output of the command
    out = subprocess.check_output(cmd, shell=True)
    # convert the output to a list
    out = out.split()
    # return the list
    return out
