from flask import Flask, request, redirect
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

# check if the email (GET variable) is in the database users and if so, unsubscribe by deleting it
@app.route('/unsubscribe')
def unsubscribe():
    # get the email (GET variable)
    email = request.args.get('email')
    # get the database connection
    db = sqlite3.connect("users.db")
    # get the current user
    cur = db.cursor()
    # get the user's id
    cur.execute("SELECT id FROM users WHERE email =?", (email,))
    # get the id of the user
    user_id = cur.fetchone()[0]
    # delete the user
    cur.execute("DELETE FROM users WHERE id =?", (user_id,))
    # close the database connection
    db.close()
    # redirect to the main page
    return redirect("/")
