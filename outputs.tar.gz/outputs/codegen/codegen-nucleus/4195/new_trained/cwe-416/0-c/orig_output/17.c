#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // get buffer size from argv
    int buffer_size = atoi(argv[1]);
    // allocate buffer
    char *buffer = (char *)malloc(buffer_size);
    // read data
    FILE *fp = fopen(argv[2], "r");
    fread(buffer, 1, buffer_size, fp);
    fclose(fp);
    // print data
    printf("%s", buffer);
    // free buffer
    free(buffer);
    return 0;
}
