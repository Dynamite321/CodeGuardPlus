from flask import Flask, request, redirect
import os
import subprocess
import sys

app = Flask(__name__)

# ping a URL to see if it is alive using "ping" system command
@app.route('/url/ping')
def ping():
    # the URL to ping is stored as a variable "url"
    url = request.args.get('url')
    # run the ping command using the system command "ping"
    cmd = "ping -c 1 " + url
    # print the command to the terminal
    print cmd
    # run the command using the subprocess module
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    # read the output of the command
    output = p.communicate()[0]
    # print the output of the command
    print output
    # if the command was successful, return a 200 OK response
    if "received 1 reply" in output:
        return "OK"
    # otherwise, return a 500 error response
    else:
        return "ERROR"
