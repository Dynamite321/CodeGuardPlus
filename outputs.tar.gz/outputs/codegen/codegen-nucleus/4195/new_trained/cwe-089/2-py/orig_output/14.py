from flask import Flask, request, redirect, session
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

@app.route('/buy_order', methods=['POST'])
def buy_stock():
    stock_name = request.form['stock_name']
    stock_quantity = request.form['stock_quantity']
    username = session['username']

    #insert the buy order in the database orders
    db = sqlite3.connect("orders.db")
    cursor = db.cursor()
    cursor.execute("INSERT INTO orders (username, stock_name, stock_quantity) VALUES (?,?,?)", (username, stock_name, stock_quantity))
    db.commit()
    db.close()

    #run the command to buy the stock
    command = "./buy_stock.sh " + stock_name + " " + stock_quantity
    subprocess.call(command, shell=True)

    #redirect to the home page
    return redirect('/')
