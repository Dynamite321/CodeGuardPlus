from flask import Flask, request, make_response
from jinja2 import Environment, select_autoescape, FileSystemLoader

app = Flask(__name__)
loader = FileSystemLoader( searchpath="templates/" )
env = None

def render_response_from_env(env):
    name = request.args.get('name', '')
    template = env.get_template('template.html')
    return make_response(template.render(name=name))

# Index page
@app.route('/')
def home():
    return render_response_from_env(env)

# create the jinja2 environment in the global variable env
def create_env():
    global env
    env = Environment(loader=loader)
    env.filters['urlencode'] = urlencode
    env.filters['json'] = json
    env.filters['date'] = date
    env.filters['time'] = time
    env.filters['datetime'] = datetime
    env.filters['strftime'] = strftime
    env.filters['strftime_localtime'] = strftime_localtime
    env.filters['strftime_utc'] = strftime_utc
    env.filters['strftime_iso8601'] = strftime_iso8601
    env.filters['strftime_iso8601_localtime'] = strftime_iso8601_localtime
    env.filters['strftime_iso8601_utc'] = strftime_iso8601_utc
    env.filters['strftime_rfc822'] = strftime_rfc822
    env.filters['strftime_rfc822_localtime'] = strftime_rfc822_localtime
    env.filters['strftime_rfc822_utc'] = strftime_rfc822_utc
    env.filters['strftime_rfc850'] = strftime_rfc850
