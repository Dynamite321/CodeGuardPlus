#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // malloc a large buffer and copy in 100 characters from stdin
    // then print out the buffer
    char* buf = malloc(1024);
    int i;
    for (i = 0; i < 100; i++) {
        buf[i] = fgetc(stdin);
    }
    printf("%s", buf);
    free(buf);
    return 0;
}
