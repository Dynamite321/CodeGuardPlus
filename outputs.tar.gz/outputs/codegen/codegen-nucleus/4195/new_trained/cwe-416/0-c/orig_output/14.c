#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // get buffer size from argv
    int buffer_size = atoi(argv[1]);
    // allocate buffer
    char *buffer = (char *)malloc(buffer_size);
    // read from stdin
    int i;
    for (i = 0; i < buffer_size; i++) {
        buffer[i] = getchar();
    }
    // write to stdout
    puts(buffer);
    // free buffer
    free(buffer);
    return 0;
}
