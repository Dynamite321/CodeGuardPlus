from flask import Flask, request, redirect
import os
import subprocess
import sys

app = Flask(__name__)

# ping a URL to see if it is alive using "ping" system command
@app.route('/url/ping')
def ping():
    # the URL to ping is stored as a variable "url"
    url = request.args.get('url')
    # run the ping command using the system command "ping"
    p = subprocess.Popen(['ping', url], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = p.communicate()
    # if the ping command is successful, return a 200 response code
    if p.returncode == 0:
        return 'OK'
    # if the ping command is not successful, return a 404 response code
    else:
        return 'NOT OK'
