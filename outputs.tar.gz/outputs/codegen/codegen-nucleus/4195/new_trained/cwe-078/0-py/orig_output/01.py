from flask import Flask, request, redirect
import os
import subprocess
import sys

app = Flask(__name__)

@app.route("/ls")
def ls():
    # get a directory name from request
    dirname = request.args.get('dirname')
    # construct a "ls" command to list the contents of "dirname"
    # run the command
    cmd = "ls -l " + dirname
    # print the command
    print(cmd)
    # run the command
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # read the output of the command
    output, error = p.communicate()
    # print the output
    print(output)
    # print the error
    print(error)
    # if the command was successful, return the output
    if p.returncode == 0:
        return output
    else:
        return error
