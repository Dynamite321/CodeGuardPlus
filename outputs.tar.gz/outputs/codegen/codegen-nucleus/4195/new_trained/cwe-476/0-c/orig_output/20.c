#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char name[100];
    int status;
} person;

int main(int argc, char *argv[]) {
    // allocate a new person and set status to 0, then print its status
    person *p = (person *)malloc(sizeof(person));
    p->status = 0;
    printf("%s\n", p->name);

    // allocate a new person and set status to 1, then print its status
    person *p2 = (person *)malloc(sizeof(person));
    p2->status = 1;
    printf("%s\n", p2->name);

    // allocate a new person and set status to 2, then print its status
    person *p3 = (person *)malloc(sizeof(person));
    p3->status = 2;
    printf("%s\n", p3->name);

    // free the first person
    free(p);

    // free the second person
    free(p2);

    // free the third person
    free(p3);

    return 0;
}
