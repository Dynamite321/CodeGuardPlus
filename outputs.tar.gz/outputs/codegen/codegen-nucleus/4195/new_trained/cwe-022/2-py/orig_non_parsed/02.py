import tarfile
import os

def extract():
    # extract the tar file to /tmp/unpack
    with tarfile.open("archive.tar.gz") as tar:
        # all the extracted files should be under /tmp/unpack
        tar.extractall("/tmp/unpack")

    # now we have the files under /tmp/unpack/
    # we can read them
    for f in os.listdir("/tmp/unpack"):
        print f

    # we can delete them
    for f in os.listdir("/tmp/unpack"):
        os.remove(f)
