from flask import Flask, request, redirect
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

# check if the email (GET variable) is in the database users and if so, unsubscribe by deleting it
@app.route('/unsubscribe')
def unsubscribe():
    # get the email (GET variable)
    email = request.args.get('email')
    # get the database connection
    db = sqlite3.connect("users.db")
    # get the user from the database
    cursor = db.cursor()
    cursor.execute("SELECT * FROM users WHERE email=?", (email,))
    # get the result of the query
    result = cursor.fetchall()
    # if the email is in the database, delete it
    if result:
        cursor.execute("DELETE FROM users WHERE email=?", (email,))
        db.commit()
    # if the email is not in the database, redirect to the main page
    else:
        return redirect("/")
