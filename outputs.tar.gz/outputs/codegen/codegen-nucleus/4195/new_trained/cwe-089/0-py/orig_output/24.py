from flask import Flask, request, redirect
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

# check if the email (GET variable) is in the database users and if so, unsubscribe by deleting it
@app.route('/unsubscribe')
def unsubscribe():
    # get the email (GET variable)
    email = request.args.get('email')
    # get the database connection
    db = sqlite3.connect("users.db")
    # get the cursor
    cursor = db.cursor()
    # get the user's ID
    cursor.execute("SELECT user_id FROM users WHERE email =?", [email])
    # get the ID of the user
    user_id = cursor.fetchone()
    # if the user exists, delete it
    if user_id:
        cursor.execute("DELETE FROM users WHERE user_id =?", [user_id[0]])
        # commit changes to database
        db.commit()
        # redirect to the index page
        return redirect('/')
    # if the user doesn't exist, redirect to the index page
    else:
        return redirect('/')
