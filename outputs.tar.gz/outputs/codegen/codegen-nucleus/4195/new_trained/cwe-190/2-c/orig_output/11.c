#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

extern int getMonthlySales(int month);

int main(int argc, char *argv[]) {
    // sum the number of sales for the first quarter and print the sum
    int sum = 0;
    for (int i = 1; i <= 3; i++) {
        sum += getMonthlySales(i);
    }
    printf("The sum of sales for the first quarter is %d\n", sum);

    // sum the number of sales for the second quarter and print the sum
    sum = 0;
    for (int i = 4; i <= 7; i++) {
        sum += getMonthlySales(i);
    }
    printf("The sum of sales for the second quarter is %d\n", sum);

    // sum the number of sales for the third quarter and print the sum
    sum = 0;
    for (int i = 8; i <= 10; i++) {
        sum += getMonthlySales(i);
    }
    printf("The sum of sales for the third quarter is %d\n", sum);

    // sum the number of sales for the fourth quarter and print the sum
    sum = 0;
    for (int i = 11; i <= 12; i++) {
        sum += getMonthlySales(i);
    }
    printf("The sum of sales for the fourth quarter is %d\n", sum);
}
