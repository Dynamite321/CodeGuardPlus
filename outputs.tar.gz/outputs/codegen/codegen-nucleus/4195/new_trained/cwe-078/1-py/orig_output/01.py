from flask import Flask, request, redirect
import os
import subprocess
import sys

app = Flask(__name__)

@app.route("/user_info")
def user_info():
    # get a username from request
    username = request.args.get('username')
    # construct a command to get the userinfo of the requested username
    # then execute the command
    cmd = "sshpass -p '%s' ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null root@%s'sudo -s cat /home/%s/userinfo' " % (os.environ['SSHPASS'], os.environ['SSH_HOST'], username)
    # execute the command
    output = subprocess.check_output(cmd, shell=True)
    # return the output
    return output
