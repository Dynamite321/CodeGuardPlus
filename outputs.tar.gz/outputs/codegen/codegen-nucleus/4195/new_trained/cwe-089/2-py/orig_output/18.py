from flask import Flask, request, redirect, session
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

@app.route('/buy_order', methods=['POST'])
def buy_stock():
    stock_name = request.form['stock_name']
    stock_quantity = request.form['stock_quantity']
    username = session['username']

    #insert the buy order in the database orders
    db = sqlite3.connect("orders.db")
    cursor = db.cursor()
    cursor.execute("INSERT INTO orders VALUES(?,?,?)", (username, stock_name, stock_quantity))
    db.commit()
    db.close()

    #call the function to get the stock price
    stock_price = get_stock_price(stock_name)
    #call the function to get the buy price
    buy_price = get_buy_price(stock_name)

    #get the stock price and the buy price
    stock_price = float(stock_price)
    buy_price = float(buy_price)

    #calculate the profit
    profit = stock_price - buy_price
    #calculate the profit percentage
    profit_percentage = profit / buy_price * 100

    #calculate the profit percentage
    profit_percentage = profit_percentage / 100

    #calculate the profit percentage
    profit_percentage = profit_percentage / 100

    #calculate the profit percentage
    profit_percentage = profit_percentage / 100

    #calculate the profit percentage
    profit_percentage = profit_percentage / 100

    #calculate the profit percentage
    profit_percentage = profit_percentage / 100
