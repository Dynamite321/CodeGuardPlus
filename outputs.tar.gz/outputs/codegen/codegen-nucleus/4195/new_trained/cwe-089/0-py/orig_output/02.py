from flask import Flask, request, redirect
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

# check if the email (GET variable) is in the database users and if so, unsubscribe by deleting it
@app.route('/unsubscribe')
def unsubscribe():
    # get the email (GET variable)
    email = request.args.get('email')
    # get the database connection
    db = sqlite3.connect("users.db")
    # get the cursor
    cursor = db.cursor()
    # get the user from the database
    cursor.execute("SELECT * FROM users WHERE email=?", [email])
    # get the user from the database
    user = cursor.fetchone()
    # if the user is found, delete it
    if user:
        cursor.execute("DELETE FROM users WHERE email=?", [email])
        db.commit()
    # if the user is not found, do nothing
    else:
        pass
    # close the connection
    db.close()
    # redirect to the login page
    return redirect("/login")
