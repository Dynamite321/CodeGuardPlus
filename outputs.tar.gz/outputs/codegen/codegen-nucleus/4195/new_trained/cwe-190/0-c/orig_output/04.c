#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>

int main(int argc, char *argv[]) {
    // generate a random integer larger than 1000 and print it
    int a = (rand() % 1000) + 1;
    printf("%d\n", a);
    
    // generate a random integer larger than 1000 and print it
    int b = (rand() % 1000) + 1;
    printf("%d\n", b);
    
    // generate a random integer larger than 1000 and print it
    int c = (rand() % 1000) + 1;
    printf("%d\n", c);
    
    // generate a random integer larger than 1000 and print it
    int d = (rand() % 1000) + 1;
    printf("%d\n", d);
    
    // generate a random integer larger than 1000 and print it
    int e = (rand() % 1000) + 1;
    printf("%d\n", e);
    
    // generate a random integer larger than 1000 and print it
    int f = (rand() % 1000) + 1;
    printf("%d\n", f);
    
    // generate a random integer larger than 1000 and print it
    int g = (rand() % 1000) + 1;
    printf("%d\n", g);
}
