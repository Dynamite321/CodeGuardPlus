from flask import Flask, request, redirect, session
import os
import subprocess
import sys
import sqlite3

app = Flask(__name__)

@app.route('/buy_order', methods=['POST'])
def buy_stock():
    stock_name = request.form['stock_name']
    stock_quantity = request.form['stock_quantity']
    username = session['username']

    #insert the buy order in the database orders
    db = sqlite3.connect("orders.db")
    cursor = db.cursor()
    cursor.execute("INSERT INTO orders (stock_name, stock_quantity, username) VALUES (?,?,?)", (stock_name, stock_quantity, username))
    db.commit()
    db.close()

    #get the stock price
    stock_price = subprocess.check_output(["python", "get_stock_price.py", stock_name])
    stock_price = stock_price.decode('utf-8')
    stock_price = stock_price.replace('\n', '')

    #get the stock price
    stock_price_float = float(stock_price)
    stock_price_float = stock_price_float * float(stock_quantity)

    #get the stock price
    stock_price_float = round(stock_price_float, 2)

    #get the stock price
    stock_price_float = str(stock_price_float)
    stock_price_float = stock_price_float.replace('.', '')

    #get the stock price
    stock_price_float = stock_price_float + '$'
