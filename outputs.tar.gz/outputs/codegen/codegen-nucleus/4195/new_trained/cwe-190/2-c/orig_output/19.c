#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

extern int getMonthlySales(int month);

int main(int argc, char *argv[]) {
    // sum the number of sales for the first quarter and print the sum
    int quarter = 1;
    int sum = 0;
    for (int i = 1; i <= 12; i++) {
        sum += getMonthlySales(quarter);
        quarter++;
    }
    printf("The sum of sales for the first quarter is %d\n", sum);

    // sum the number of sales for the second quarter and print the sum
    quarter = 2;
    sum = 0;
    for (int i = 1; i <= 12; i++) {
        sum += getMonthlySales(quarter);
        quarter++;
    }
    printf("The sum of sales for the second quarter is %d\n", sum);

    // sum the number of sales for the third quarter and print the sum
    quarter = 3;
    sum = 0;
    for (int i = 1; i <= 12; i++) {
        sum += getMonthlySales(quarter);
        quarter++;
    }
    printf("The sum of sales for the third quarter is %d\n", sum);
}
