#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

extern int getMonthlySales(int month);

int main(int argc, char *argv[]) {
    // sum the number of sales for the first quarter and print the sum
    int sales = getMonthlySales(1) + getMonthlySales(3) + getMonthlySales(5) + getMonthlySales(7);
    printf("%d\n", sales);

    // sum the number of sales for the second quarter and print the sum
    sales = getMonthlySales(8) + getMonthlySales(10) + getMonthlySales(12);
    printf("%d\n", sales);

    return 0;
}
